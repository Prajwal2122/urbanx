import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "../api/axios"; // Make sure this file exists
import "../index.css";

const HomePage = () => {
  const [services, setServices] = useState([]);

  useEffect(() => {
  const fetchServices = async () => {
    try {
      const res = await axios.get("/services");
      setServices(res.data);
      console.log("📦 Fetched Services:", res.data);
    } catch (err) {
      console.error("❌ Error fetching services:", err);
    }
  };
  fetchServices();
}, []);


  return (
    <div>
      {/* 🧾 CTA Section */}
      <section className="cta-section fade-in-up delay-1">
        <h1>Need a Service? Book Now in Seconds!</h1>
        <Link to="/register" className="cta-btn">Get Started</Link>
      </section>

      {/* 🛠️ Dynamic Services */}
      <section className="container section fade-in-up delay-2">
        <h2 className="section-title">Popular Services</h2>
        <div className="enhanced-card-grid">
          {services.length === 0 ? (
            <p>No services available.</p>
          ) : (
            services.map((service, index) => (
              <Link
                to={`/services/${service.category}`}
                key={index}
                className="enhanced-service-card"
              >
                <div
                  className="enhanced-card-image"
                  style={{
                    backgroundImage: `url(${service.image || "/images/default.jpg"})`,
                  }}
                />
                <div className="enhanced-card-content">
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <span className="card-arrow">→</span>
                </div>
              </Link>
            ))
          )}
        </div>
      </section>

      {/* 💼 Categories Section */}
      <section className="container section fade-in-up delay-1">
        <h2 className="section-title">Explore Services by Category</h2>
        <div className="category-card-grid">
          {[
            { name: "Cleaning", icon: "🧹", color: "#ffeaa7" },
            { name: "AC Repair", icon: "❄️", color: "#dff9fb" },
            { name: "Carpentry", icon: "🪚", color: "#fab1a0" },
            { name: "Painting", icon: "🎨", color: "#e1bee7" },
            { name: "Pest Control", icon: "🐜", color: "#f8d7da" },
            { name: "Home Shifting", icon: "📦", color: "#c8e6c9" }
          ].map((item, index) => (
            <div
              className="category-card"
              style={{ backgroundColor: item.color }}
              key={index}
            >
              <span className="emoji-icon">{item.icon}</span>
              <h3>{item.name}</h3>
            </div>
          ))}
        </div>
      </section>

      {/* 🛡️ Trust Section */}
      <section className="trust-section fade-in-up delay-1">
        <div className="container">
          <h2>Your Safety, Our Priority</h2>
          <p>All professionals are background-verified, vaccinated, and follow safety protocols.</p>
          <div className="trust-icons">
            <div><img src="/assets/verified.png" alt="Verified" /><p>Verified Pros</p></div>
            <div><img src="/assets/mask.png" alt="Mask" /><p>Safety Gear</p></div>
            <div><img src="/assets/sanitizer.png" alt="Sanitizer" /><p>Sanitized Tools</p></div>
          </div>
        </div>
      </section>

      {/* 📞 Support Section */}
      <section className="support-section fade-in-up delay-2">
        <div className="container">
          <h2>Need Help?</h2>
          <p>Our support team is available 24/7 to assist you with any service issue.</p>
          <Link to="/contact" className="support-btn">Contact Support</Link>
        </div>
      </section>

      {/* 🚀 How It Works Section */}
      <section className="journey-section fade-in-up">
        <div className="container">
          <h2 className="section-title">How UrbanX Works</h2>
          <div className="journey-timeline">
            <div className="journey-step">
              <div className="step-icon">🔍</div>
              <h4>Search</h4>
              <p>Find services in your location easily.</p>
            </div>
            <div className="journey-step">
              <div className="step-icon">📅</div>
              <h4>Book</h4>
              <p>Select your preferred time & expert.</p>
            </div>
            <div className="journey-step">
              <div className="step-icon">🛠️</div>
              <h4>Service</h4>
              <p>Our expert completes the task on time.</p>
            </div>
            <div className="journey-step">
              <div className="step-icon">🌟</div>
              <h4>Rate</h4>
              <p>Leave feedback & help us improve!</p>
            </div>
          </div>
        </div>
      </section>

      {/* ✨ Become Provider */}
      <section className="become-provider fade-in-up delay-3">
        <div className="container">
          <h2>Join Us as a Service Expert</h2>
          <p>Earn from your skills by joining UrbanX as a verified professional.</p>
          <Link to="/provider-register" className="provider-btn">Register as Provider</Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
