import React, { useState } from 'react';
import '../index.css';

const Contact = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="contact-container">
      <h2>Contact Support</h2>
      <p className="subtitle">Have a question or issue? We're here to help 24/7.</p>

      {submitted ? (
        <div className="thank-you-message">
          <h3>✅ Thank you!</h3>
          <p>Your message has been submitted. Our support team will contact you shortly.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="contact-form">
          <label>Your Name</label>
          <input type="text" placeholder="John Doe" required />

          <label>Email</label>
          <input type="email" placeholder="you@example.com" required />

          <label>Phone</label>
          <input type="tel" placeholder="9876543210" required />

          <label>Message</label>
          <textarea placeholder="Write your message..." required />

          <button type="submit">Submit</button>
        </form>
      )}
    </div>
  );
};

export default Contact;
