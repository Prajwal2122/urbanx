import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from '../pages/HomePage';
import Register from '../pages/Register';
import Login from '../pages/Login';
import ServiceDetails from '../components/ServiceDetails';
import Contact from "../pages/Contact";
import ProviderRegister from "../pages/ProviderRegister";
import Services from "../pages/Services";
import CategoryServices from '../pages/CategoryServices';// ✅ Correct import name

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />
      <Route path="/services/:category" element={<ServiceDetails />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/provider-register" element={<ProviderRegister />} />
      <Route path="/services" element={<Services />} />

      {/* ✅ Corrected route path for category-based service listing */}
<Route path="/category/:category" element={<CategoryServices />} />

    </Routes>
  );
};

export default AppRoutes;
