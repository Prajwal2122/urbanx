import axios from 'axios';

const instance = axios.create({
  baseURL: 'http://localhost:8000/api',  // ✅ यही होना चाहिए
  withCredentials: true,
});

export default instance;
