import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "../api/axios";
import "../index.css";

const ServiceDetails = () => {
  const { category } = useParams();
  const [formData, setFormData] = useState({
    userName: "",
    phone: "",
    address: "",
    dateTime: "",
    note: ""
  });

  const [serviceId, setServiceId] = useState("");

  // Step 1: Fetch serviceId based on category in URL
  useEffect(() => {
    const fetchService = async () => {
      try {
        const res = await axios.get("/services");
        const matched = res.data.find(service => service.category === category);
        if (matched) {
          setServiceId(matched._id);
        }
      } catch (err) {
        console.error("❌ Error fetching service ID", err);
      }
    };
    fetchService();
  }, [category]);

  // Step 2: Handle input changes
  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  // Step 3: Submit booking
  const handleSubmit = async (e) => {
    e.preventDefault();

    const payload = {
      userName: formData.userName,
      phone: formData.phone,
      address: formData.address,
      date: formData.dateTime.split("T")[0],
      time: formData.dateTime.split("T")[1],
      service: serviceId,
      note: formData.note
    };

    try {
      const res = await axios.post("/bookings", payload);
      alert("✅ Booking Confirmed!");
      console.log("Response:", res.data);

      // Clear form
      setFormData({
        userName: "",
        phone: "",
        address: "",
        dateTime: "",
        note: ""
      });
    } catch (err) {
      console.error("Booking Error:", err);
      alert("❌ Booking Failed: " + (err.response?.data?.message || "Server error"));
    }
  };

  return (
    <div className="service-detail-container">
      <h2>Book a {category.charAt(0).toUpperCase() + category.slice(1)} Service</h2>

      <form className="booking-form" onSubmit={handleSubmit}>
        <label>Your Full Name</label>
        <input
          type="text"
          name="userName"
          value={formData.userName}
          onChange={handleChange}
          placeholder="John Doe"
          required
        />

        <label>Phone Number</label>
        <input
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="9876543210"
          required
        />

        <label>Preferred Date & Time</label>
        <input
          type="datetime-local"
          name="dateTime"
          value={formData.dateTime}
          onChange={handleChange}
          required
        />

        <label>Address</label>
        <textarea
          name="address"
          value={formData.address}
          onChange={handleChange}
          placeholder="Enter your address"
          required
        />

        <label>Additional Note (Optional)</label>
        <textarea
          name="note"
          value={formData.note}
          onChange={handleChange}
          placeholder="Any extra instruction..."
        />

        <button type="submit">Confirm Booking</button>
      </form>
    </div>
  );
};

export default ServiceDetails;
