// File: src/components/Slider.jsx
import React, { useState, useEffect } from 'react';
import '../index.css';

const slides = [
  { id: 1, image: '/5.jpg', caption: 'Home Cleaning Experts' },
  { id: 2, image: '/assets/slide2.jpg', caption: 'Beauty Services at Home' },
  { id: 3, image: '/assets/slide3.jpg', caption: 'Plumbing, AC & Repairs' },
];

const Slider = () => {
  const [index, setIndex] = useState(0);

  const nextSlide = () => setIndex((index + 1) % slides.length);
  const prevSlide = () => setIndex((index - 1 + slides.length) % slides.length);

  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [index]);

  return (
    <div className="custom-slider">
      {slides.map((slide, i) => (
        <div
          key={slide.id}
          className={`custom-slide ${i === index ? 'active' : ''}`}
          style={{ backgroundImage: `url(${slide.image})` }}
        >
          <div className="slide-overlay"></div>
          <div className="custom-caption">
            <h2>{slide.caption}</h2>
          </div>
        </div>
      ))}
      <button className="slider-btn prev" onClick={prevSlide}>❮</button>
      <button className="slider-btn next" onClick={nextSlide}>❯</button>
    </div>
  );
};

export default Slider;
