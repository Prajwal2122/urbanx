const Service = require('../models/Service');

// ✅ Create Service
exports.createService = async (req, res) => {
  try {
    const { title, description, category, price, image, provider } = req.body;

    // Validate all fields
    if (!title || !description || !category || !price || !provider || !image) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    const newService = new Service({
      title,
      description,
      category: category.toLowerCase(), // Normalize category
      price,
      image,
      provider
    });

    await newService.save();
    res.status(201).json(newService);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// ✅ Get All Services
exports.getAllServices = async (req, res) => {
  try {
    const services = await Service.find().populate('provider', 'name email');
    res.json(services);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// ✅ Get Services by Category
// ✅ Get Services by Category
exports.getServicesByCategory = async (req, res) => {
  try {
    const { category } = req.params;
    const services = await Service.find({ category }); // match by category
    if (!services.length) {
      return res.status(404).json({ message: "No services found in this category." });
    }
    res.json(services);
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

