const Booking = require("../models/Booking");

exports.createBooking = async (req, res) => {
  try {
    const { userName, phone, address, date, time, note, service } = req.body;

    // ✅ Check for required fields
    if (!userName || !phone || !address || !date || !time || !service) {
      return res.status(400).json({ message: "All fields are required." });
    }

    const newBooking = new Booking({
      userName,
      phone,
      address,
      date,
      time,
      note,
      service
    });

    await newBooking.save();
    res.status(201).json({ message: "Booking successful", booking: newBooking });

  } catch (err) {
    console.error("Booking Error:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};
