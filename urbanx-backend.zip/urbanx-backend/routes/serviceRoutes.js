const express = require('express');
const router = express.Router();
const {
  createService,
  getAllServices,
  getServicesByCategory // ✅ required
} = require('../controllers/serviceController');

router.get('/', getAllServices);
router.post('/', createService);
router.get('/category/:category', getServicesByCategory); // ✅ This must exist

module.exports = router;
