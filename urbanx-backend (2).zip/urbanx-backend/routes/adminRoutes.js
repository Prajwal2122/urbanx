const express = require('express');
const router = express.Router();
const {
  getAllBookings,
  getAllServices,
  updateBookingStatus,
  deleteService
} = require('../controllers/adminController');

const { verifyToken } = require('../middleware/authMiddleware');

// ✅ FIXED ROUTES
router.get('/bookings', verifyToken, getAllBookings);
router.get('/services', verifyToken, getAllServices);

// ✅ Matches PUT /api/admin/bookings/:id
router.put('/bookings/:id', verifyToken, updateBookingStatus);

// ✅ Matches DELETE /api/admin/services/:id
router.delete('/services/:id', verifyToken, deleteService);

module.exports = router;
