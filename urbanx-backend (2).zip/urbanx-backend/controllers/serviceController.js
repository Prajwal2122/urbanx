const Service = require('../models/Service');

exports.createService = async (req, res) => {
  try {
    const { title, description, category, price, image, provider } = req.body;

    if (!title || !description || !category || !price || !provider || !image) {
      return res.status(400).json({ message: 'All fields are required.' });
    }

    const newService = new Service({
      title,
      description,
      category,
      price,
      image,
      provider
    });

    await newService.save();
    res.status(201).json(newService);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

exports.getAllServices = async (req, res) => {
  try {
    const services = await Service.find().populate('provider', 'name email');
    res.json(services);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
