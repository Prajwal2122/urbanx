const Booking = require('../models/Booking');
const Service = require('../models/Service');

// Get all bookings
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find().populate('service');
    res.json(bookings);
  } catch {
    res.status(500).json({ message: 'Error fetching bookings' });
  }
};

// Get all services
exports.getAllServices = async (req, res) => {
  try {
    const services = await Service.find();
    res.json(services);
  } catch {
    res.status(500).json({ message: 'Error fetching services' });
  }
};

// ✅ Update booking status
exports.updateBookingStatus = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ message: 'Booking not found' });

    booking.status = 'confirmed'; // or any fixed update you want
    await booking.save();

    res.json({ message: 'Booking status updated', booking });
  } catch {
    res.status(500).json({ message: 'Error updating booking status' });
  }
};

// ✅ Delete service
exports.deleteService = async (req, res) => {
  try {
    await Service.findByIdAndDelete(req.params.id);
    res.json({ message: 'Service deleted successfully' });
  } catch {
    res.status(500).json({ message: 'Error deleting service' });
  }
};
